using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    [SerializeField] float speed = 5f;
    [SerializeField] float jumpforce = 3f;
    [SerializeField] float sensitivity = 1f;
    private Rigidbody _rb;
    private float x;
    private float y;


    private Vector3 rotation;

    // Start is called before the first frame update
    void Start()
    {
        _rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float inputx = Input.GetAxisRaw("Horizontal");
        float inputz = Input.GetAxisRaw("Vertical");
        float inputy = Input.GetAxisRaw("Jump");

        Vector3 movement = new Vector3(inputx * speed, inputy * jumpforce, inputz * speed);
        _rb.MovePosition(_rb.position + movement * Time.deltaTime);
        x = Input.GetAxis("Mouse Y") * sensitivity * Time.deltaTime;
        y = Input.GetAxis("Mouse X") * sensitivity * Time.deltaTime;

        

     


    }

}
